package cn.edu.cqrk.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
public class DevPlan extends Model<DevPlan> {

    private static final long serialVersionUID=1L;
    
    @TableId(type=IdType.AUTO)
    private Integer plId;

    /**
     * 销售机会编号
     */
    private Integer scId;

    /**
     * 计划日期
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd") //设置页面输入格式，如：2020-09-18 10:06:25
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8") //设置日期在表格里的显示格式

    private LocalDate plDate;

    /**
     * 计划内容
     */
    private String plDetails;

    /**
     * 执行日期
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd") //设置页面输入格式，如：2020-09-18 10:06:25
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8") //设置日期在表格里的显示格式
    private LocalDate plExdate;

    /**
     * 执行结果：1、成功；2失败
     */
    private Integer plResult;

    /**
     * 执行人
     */
    private String plPerson;
    
    
    


    public Integer getPlId() {
		return plId;
	}

	public void setPlId(Integer plId) {
		this.plId = plId;
	}

	public Integer getScId() {
        return scId;
    }

    public void setScId(Integer scId) {
        this.scId = scId;
    }

  

    public LocalDate getPlDate() {
		return plDate;
	}

	public void setPlDate(LocalDate plDate) {
		this.plDate = plDate;
	}

	public String getPlDetails() {
        return plDetails;
    }

    public void setPlDetails(String plDetails) {
        this.plDetails = plDetails;
    }

    

    public LocalDate getPlExdate() {
		return plExdate;
	}

	public void setPlExdate(LocalDate plExdate) {
		this.plExdate = plExdate;
	}

	public Integer getPlResult() {
        return plResult;
    }

    public void setPlResult(Integer plResult) {
        this.plResult = plResult;
    }

    public String getPlPerson() {
        return plPerson;
    }

    public void setPlPerson(String plPerson) {
        this.plPerson = plPerson;
    }

    @Override
    protected Serializable pkVal() {
        return this.scId;
    }

    @Override
    public String toString() {
        return "DevPlan{" +
        "scId=" + scId +
        ", plDate=" + plDate +
        ", plDetails=" + plDetails +
        ", plExdate=" + plExdate +
        ", plResult=" + plResult +
        ", plPerson=" + plPerson +
        "}";
    }
}
