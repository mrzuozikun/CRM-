package cn.edu.cqrk.service;

import cn.edu.cqrk.entity.SaleChangce;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author CQRW
 * @since 2020-09-17
 */
public interface ISaleChangceService extends IService<SaleChangce> {

}
