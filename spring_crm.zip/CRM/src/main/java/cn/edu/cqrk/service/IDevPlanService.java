package cn.edu.cqrk.service;

import cn.edu.cqrk.entity.DevPlan;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
public interface IDevPlanService extends IService<DevPlan> {

}
