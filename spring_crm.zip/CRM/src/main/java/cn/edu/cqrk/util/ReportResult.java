package cn.edu.cqrk.util;

import java.util.ArrayList;
import java.util.List;

public class ReportResult {
	private List<Integer> data = new ArrayList<>() ;
	private List<String> xAxis = new ArrayList<>();
	private List<Integer> yAxis = new ArrayList<>();
	public List<String> getxAxis() {
		return xAxis;
	}
	public void setxAxis(List<String> xAxis) {
		this.xAxis = xAxis;
	}
	public List<Integer> getyAxis() {
		return yAxis;
	}
	public void setyAxis(List<Integer> yAxis) {
		this.yAxis = yAxis;
	}
	public List<Integer> getData() {
		return data;
	}
	public void setData(List<Integer> data) {
		this.data = data;
	}
	
	
}
