package cn.edu.cqrk.mapper;

import cn.edu.cqrk.entity.DevPlan;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
public interface DevPlanMapper extends BaseMapper<DevPlan> {

}
