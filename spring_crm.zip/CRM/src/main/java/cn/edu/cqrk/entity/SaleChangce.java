package cn.edu.cqrk.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author CQRW
 * @since 2020-09-17
 */
public class SaleChangce extends Model<SaleChangce> {

    private static final long serialVersionUID=1L;

    /**
     * 机会编号
     */
    @TableId(value = "sc_id")
    private Integer scId;

    /**
     * 公司名称
     */
    private String scName;

    /**
     * 机会来源
     */
    private Integer scFrom;

    /**
     * 联系人
     */
    private String scContact;

    /**
     * 联系电话
     */
    private String scPhone;

    /**
     * 成功几率
     */
    private Integer scRate;

    /**
     * 概要描述
     */
    private String scSum;

    /**
     * 详细描述
     */
    private String scDesc;

    /**
     * 创建人
     */
    private String scCreater;

    /**
     * 创建时间
     */
    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") //设置页面输入格式，如：2020-09-18 10:06:25
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8") //设置日期在表格里的显示格式
    private LocalDateTime scDate;

    /**
     * 指派人
     */
    private String scAssign;

    /**
     * 指派时间
     */
    private LocalDateTime scAssignDate;

    /**
     * 状态：
     */
    private Integer scStatus;
    @TableField(exist = false)
    private Integer scStatusCN;
    public String getscStatusCN() {
    	String res="";
    	if(scStatus != null) {
    		switch(scStatus) {
    		case 1:
    			res="未分配";
    			break;
    		case 2:
    			res="已分配";
    			break;
    		case 3:
    			res="开发成功";
    			break;
    		case 4:
    			res="开发失败";
    			break;
    		}
    	}
    	return res;
    }
    


    public Integer getScId() {
        return scId;
    }

    public void setScId(Integer scId) {
        this.scId = scId;
    }

    public String getScName() {
        return scName;
    }

    public void setScName(String scName) {
        this.scName = scName;
    }

    public Integer getScFrom() {
        return scFrom;
    }

    public void setScFrom(Integer scFrom) {
        this.scFrom = scFrom;
    }

    public String getScContact() {
        return scContact;
    }

    public void setScContact(String scContact) {
        this.scContact = scContact;
    }

    public String getScPhone() {
        return scPhone;
    }

    public void setScPhone(String scPhone) {
        this.scPhone = scPhone;
    }

    public Integer getScRate() {
        return scRate;
    }

    public void setScRate(Integer scRate) {
        this.scRate = scRate;
    }

    public String getScSum() {
        return scSum;
    }

    public void setScSum(String scSum) {
        this.scSum = scSum;
    }

    public String getScDesc() {
        return scDesc;
    }

    public void setScDesc(String scDesc) {
        this.scDesc = scDesc;
    }

    public String getScCreater() {
        return scCreater;
    }

    public void setScCreater(String scCreater) {
        this.scCreater = scCreater;
    }

    public LocalDateTime getScDate() {
        return scDate;
    }

    public void setScDate(LocalDateTime scDate) {
        this.scDate = scDate;
    }

    public String getScAssign() {
        return scAssign;
    }

    public void setScAssign(String scAssign) {
        this.scAssign = scAssign;
    }

    public LocalDateTime getScAssignDate() {
        return scAssignDate;
    }

    public void setScAssignDate(LocalDateTime scAssignDate) {
        this.scAssignDate = scAssignDate;
    }

    public Integer getScStatus() {
        return scStatus;
    }

    public void setScStatus(Integer scStatus) {
        this.scStatus = scStatus;
    }

    @Override
    protected Serializable pkVal() {
        return this.scId;
    }

    @Override
    public String toString() {
        return "SaleChangce{" +
        "scId=" + scId +
        ", scName=" + scName +
        ", scFrom=" + scFrom +
        ", scContact=" + scContact +
        ", scPhone=" + scPhone +
        ", scRate=" + scRate +
        ", scSum=" + scSum +
        ", scDesc=" + scDesc +
        ", scCreater=" + scCreater +
        ", scDate=" + scDate +
        ", scAssign=" + scAssign +
        ", scAssignDate=" + scAssignDate +
        ", scStatus=" + scStatus +
        "}";
    }
}
