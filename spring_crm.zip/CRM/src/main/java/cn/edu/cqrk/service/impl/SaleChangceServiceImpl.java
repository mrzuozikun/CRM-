package cn.edu.cqrk.service.impl;

import cn.edu.cqrk.entity.SaleChangce;
import cn.edu.cqrk.mapper.SaleChangceMapper;
import cn.edu.cqrk.service.ISaleChangceService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author CQRW
 * @since 2020-09-17
 */
@Service
public class SaleChangceServiceImpl extends ServiceImpl<SaleChangceMapper, SaleChangce> implements ISaleChangceService {

}
