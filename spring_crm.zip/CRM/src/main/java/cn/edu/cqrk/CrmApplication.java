package cn.edu.cqrk;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;

@SpringBootApplication
@RestController
@MapperScan("cn.ed。77u.cqrk.mapper")//让Spring能够找到Mybatis的mapper接口的包（cn.edu.cqrk.mapper）
public class CrmApplication {//SpringBoot主类（启动类）

	
	public static void main(String[] args) {
		SpringApplication.run(CrmApplication.class, args);
		
	}
	
	@RequestMapping("/hello")//将其注解为一个
	public String say() {
		return "RCM_左自坤";
	}
	//向Spring容器中注入mybatis分页插件
	@Bean
	public PaginationInterceptor createPaginationInterceptor() {
		return new PaginationInterceptor();
	}
}
