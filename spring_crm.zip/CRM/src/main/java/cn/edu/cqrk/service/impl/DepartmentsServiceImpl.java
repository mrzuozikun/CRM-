package cn.edu.cqrk.service.impl;

import cn.edu.cqrk.entity.Departments;
import cn.edu.cqrk.mapper.DepartmentsMapper;
import cn.edu.cqrk.service.IDepartmentsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author CQRW
 * @since 2020-09-14
 */
@Service//创建一个实例，存放到容器
public class DepartmentsServiceImpl extends ServiceImpl<DepartmentsMapper, Departments> implements IDepartmentsService {

}
