package cn.edu.cqrk.util;

import java.util.List;

public class PageResult<T> {
	private Integer code;
	private String msg;
	private Long count;
	private List<T> data;
//	private List<T> date;
	
	
	
//	public PageResult(Integer code, String msg, Long count, List<T> data) {
//		super();
//		this.code = code;
//		this.msg = msg;
//		this.count = count;
//		this.data = data;
//	}
	
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	public List<T> getData() {
		return data;
	}
	public void setData(List<T> data) {
		this.data = data;
	}
//	public List<T> getDate() {
//		return date;
//	}
//	public void setDate(List<T> date) {
//		this.date = date;
//	}
//	
	
	

}
