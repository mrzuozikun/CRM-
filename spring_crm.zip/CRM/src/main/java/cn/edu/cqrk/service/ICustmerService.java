package cn.edu.cqrk.service;

import cn.edu.cqrk.entity.Custmer;
import cn.edu.cqrk.util.ReportEntity;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
public interface ICustmerService extends IService<Custmer> {
	public List<ReportEntity> selectCustmerCountByLevel();

}
