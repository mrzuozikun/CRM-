package cn.edu.cqrk.service;

import cn.edu.cqrk.entity.Departments;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author CQRW
 * @since 2020-09-14
 */
public interface IDepartmentsService extends IService<Departments> {

}
