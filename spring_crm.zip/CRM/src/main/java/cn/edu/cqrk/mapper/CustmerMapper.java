package cn.edu.cqrk.mapper;

import cn.edu.cqrk.entity.Custmer;
import cn.edu.cqrk.util.ReportEntity;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
public interface CustmerMapper extends BaseMapper<Custmer> {
	@Select("SELECT count(*) as num,cus_level as item FROM custmer GROUP BY cus_level")
	public List<ReportEntity> selectCustmerCountByLevel();
	

}
