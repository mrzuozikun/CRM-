package cn.edu.cqrk.service.impl;

import cn.edu.cqrk.entity.Custmer;
import cn.edu.cqrk.mapper.CustmerMapper;
import cn.edu.cqrk.service.ICustmerService;
import cn.edu.cqrk.util.ReportEntity;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
@Service
public class CustmerServiceImpl extends ServiceImpl<CustmerMapper, Custmer> implements ICustmerService {

	@Override
	public List<ReportEntity> selectCustmerCountByLevel() {
		//baseMapper是ServiceImpl里面的mapper对象
		return baseMapper.selectCustmerCountByLevel();
	}
	
}
