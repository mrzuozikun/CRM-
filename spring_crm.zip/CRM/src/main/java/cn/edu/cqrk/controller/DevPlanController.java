package cn.edu.cqrk.controller;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.edu.cqrk.entity.Custmer;
import cn.edu.cqrk.entity.Departments;
import cn.edu.cqrk.entity.DevPlan;
import cn.edu.cqrk.entity.SaleChangce;
import cn.edu.cqrk.service.IDevPlanService;
import cn.edu.cqrk.util.PageResult;
import cn.edu.cqrk.util.Result;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.apache.ibatis.annotations.ResultMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
@RestController
@CrossOrigin
@RequestMapping("/devPlan")
public class DevPlanController {
	@Autowired
	private IDevPlanService devPlanService;
	
	@RequestMapping("/getdevPlan")
	public PageResult<DevPlan> getDepartments(Integer page,Integer limit){
		 Page<DevPlan> p = new Page<>(page,limit);//创建Page对象，他是Service的page方法需要的参数类型
		Page<DevPlan> page2 = devPlanService.page(p);
		PageResult<DevPlan> pageResult = new PageResult<>();
		pageResult.setCode(0);//返回数据成功
		pageResult.setMsg("查询数据成功");
		pageResult.setCount((long)page2.getTotal());//表里面的总记录数
		pageResult.setData(page2.getRecords());//获取当前页的数据
		return pageResult;
		}
	
	
	@RequestMapping("adddevPlan")
	public Result addCustmerPlan(DevPlan deplan) {
		devPlanService.save(deplan);
		//saleChangce.setScDate(LocalDateTime.now());
		return new Result(0, "增加信息成功");
	}
	
	@RequestMapping("updevPlan")
	public Result adddevPlan(DevPlan deplan) {
		deplan.setPlExdate(LocalDate.now());
		devPlanService.updateById(deplan);
		return new Result(0,"信息修改成功");
	}

}

