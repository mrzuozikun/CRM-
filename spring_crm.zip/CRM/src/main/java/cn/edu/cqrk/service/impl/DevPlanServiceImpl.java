package cn.edu.cqrk.service.impl;

import cn.edu.cqrk.entity.DevPlan;
import cn.edu.cqrk.mapper.DevPlanMapper;
import cn.edu.cqrk.service.IDevPlanService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
@Service
public class DevPlanServiceImpl extends ServiceImpl<DevPlanMapper, DevPlan> implements IDevPlanService {

}
