package cn.edu.cqrk.controller;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.edu.cqrk.entity.Departments;
import cn.edu.cqrk.entity.SaleChangce;
import cn.edu.cqrk.service.IDepartmentsService;
import cn.edu.cqrk.service.ISaleChangceService;
import cn.edu.cqrk.util.PageResult;
import cn.edu.cqrk.util.Result;

import java.time.LocalDateTime;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author CQRW
 * @since 2020-09-17
 */
@RestController
@RequestMapping("/saleChangce")
@CrossOrigin
public class SaleChangceController {
	@Autowired//自动装配,里面装配了各种对象，需要什么就给你赋值什么
	private ISaleChangceService saleChangceService;
	/*
	 * @Autowired 
	 * private ICustomerService customerService;
	 */
	
	
	@RequestMapping("/getsaleChangce")//方法映射的URL，访问的话要类的URL加上个方法的URL
	//page：第几页、limit：每页行数.是前端表格提交的参数
	public PageResult<SaleChangce> getSaleChangce(Integer page,Integer limit){
		Page<SaleChangce> p = new Page<>(page,limit);//创建Page对象，他是Service的page方法需要的参数类型
		Page<SaleChangce> page2 = saleChangceService.page(p);
		PageResult<SaleChangce> pageResult = new PageResult<>();
		pageResult.setCode(0);//返回数据成功
		pageResult.setMsg("查询数据成功");
		pageResult.setCount((long)page2.getTotal());//表里面的总记录数
		pageResult.setData(page2.getRecords());//获取当前页的数据
		return pageResult;
		}
	
	
	@RequestMapping("addsaleChangce")
	public Result addsaleChangce(SaleChangce saleChangce) {
		saleChangce.setScDate(LocalDateTime.now());
		saleChangce.setScCreater("左自坤");
		saleChangceService.save(saleChangce);
		return new Result(0,"信息修改成功");
	}
	
	@RequestMapping("/delsaleChangce")
	public Result delsaleChangce(Integer[] scId) {
		saleChangceService.removeByIds(Arrays.asList(scId));//要标注那个字段是主键
		return new Result(0, "删除成功");
	}
	

	@RequestMapping("/upsaleChangce")
	public Result upDepartments(SaleChangce saleChangce) {
			saleChangceService.updateById(saleChangce);
			/*
			 * Customer customer = new Customer();
			 * customer.setCustName(saleChangce.getScName());
			 * customerService.save(customer);
			 */
			return new Result(0,"信息修改成功");
	
	}

}

