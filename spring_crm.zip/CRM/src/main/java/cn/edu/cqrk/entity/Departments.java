package cn.edu.cqrk.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author CQRW
 * @since 2020-09-14
 */
public class Departments extends Model<Departments> {

    private static final long serialVersionUID=1L;//

    @TableId(value = "department_id")//数据库中勾选了自动增长
    private Integer departmentId;

    private String departmentName;

    private Integer managerId;

    private Integer locationId;


    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    public Integer getLocationId() {
        return locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    @Override
    protected Serializable pkVal() {
        return this.departmentId;
    }

    @Override
    public String toString() {
        return "Departments{" +
        "departmentId=" + departmentId +
        ", departmentName=" + departmentName +
        ", managerId=" + managerId +
        ", locationId=" + locationId +
        "}";
    }
}
