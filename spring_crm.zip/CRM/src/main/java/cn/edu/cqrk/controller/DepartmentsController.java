package cn.edu.cqrk.controller;


import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;


import cn.edu.cqrk.entity.Departments;
import cn.edu.cqrk.service.IDepartmentsService;
import cn.edu.cqrk.util.PageResult;
import cn.edu.cqrk.util.Result;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author CQRW
 * @since 2020-09-14
 */
@RestController//这个类是控制层的类，返回的内容为JSON格式；@Controller是返回页面
@RequestMapping("/departments")
@CrossOrigin//允许跨域访问
public class DepartmentsController {
	@Autowired//自动装配,里面装配了各种对象，需要什么就给你赋值什么
	private IDepartmentsService departmentservice;
	
	
	
	@RequestMapping("/getdepartments")//方法映射的URL，访问的话要类的URL加上个方法的URL
	//page：第几页、limit：每页行数.是前端表格提交的参数
	public PageResult<Departments> getDepartments(Integer page,Integer limit){
		Page<Departments> p = new Page<>(page,limit);//创建Page对象，他是Service的page方法需要的参数类型
		Page<Departments> page2 = departmentservice.page(p);
		PageResult<Departments> pageResult = new PageResult<>();
		pageResult.setCode(0);//返回数据成功
		pageResult.setMsg("查询数据成功");
		pageResult.setCount((long)page2.getTotal());//表里面的总记录数
		pageResult.setData(page2.getRecords());//获取当前页的数据
		return pageResult;
		}
	
	
	
	
	@RequestMapping("/addDepartments")
	public Result addDepartments(Departments departments) {
		departmentservice.save(departments);
		return new Result(0,"信息修改成功");
	}
	
	
	
	
	@RequestMapping("/delDepartments")
	public Result delDepartments(Integer[] departmentId) {
		departmentservice.removeByIds(Arrays.asList(departmentId));//要标注那个字段是主键
		return new Result(0, "删除成功");
	}
	

	
	@RequestMapping("/upDepartments")
	public Result upDepartments(Departments departments) {
		departmentservice.updateById(departments);
		return new Result(0,"信息修改成功");
		
	}

}

