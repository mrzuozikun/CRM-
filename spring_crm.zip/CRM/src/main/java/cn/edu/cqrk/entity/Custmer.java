package cn.edu.cqrk.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
public class Custmer extends Model<Custmer> {

    private static final long serialVersionUID=1L;

    /**
     * 客户编号
     */
    @TableId(value = "cus_id")
    private Integer cusId;

    /**
     * 客户姓名
     */
    private String cusName;

    /**
     * 客户地区：
     */
    private Integer cusRegion;
  

	/**
     * 客户行业:1金融、2房地产、3商业服务、4运输物流、5生产、6征服、7文化传媒、8其它
     */
    private Integer cusIndusty;

    /**
     * 客户等级：1（重点客户）、2（普通客户）、3（非优先客户）
     */
    private Integer cusLevel;

    /**
     * 客户满意度：1、非常满意2、满意、3、一般
4、不满意、5非常不满意
     */
    private Integer cusSatisfacyion;

    /**
     * 客户信誉等级：1、极高2、高、3、一般
4、低、5极低
     */
    private Integer cusCredit;

    /**
     * 客户地址
     */
    private String cusAddress;

    /**
     * 客户网址
     */
    private String cusUrl;

    /**
     * 客户邮编
     */
    private String cusZipcode;

    /**
     * 客户电话
     */
    private String cusPhone;

    /**
     * 客户传真
     */
    private String cusFox;

    /**
     * 客户状态
1：正常2、流失
     */
    private Integer cusStatus;


    public Integer getCusId() {
        return cusId;
    }

    public void setCusId(Integer cusId) {
        this.cusId = cusId;
    }

    public String getCusName() {
        return cusName;
    }

    public void setCusName(String cusName) {
        this.cusName = cusName;
    }

    public Integer getCusRegion() {
        return cusRegion;
    }

    public void setCusRegion(Integer cusRegion) {
        this.cusRegion = cusRegion;
    }

    public Integer getCusIndusty() {
        return cusIndusty;
    }

    public void setCusIndusty(Integer cusIndusty) {
        this.cusIndusty = cusIndusty;
    }

    public Integer getCusLevel() {
        return cusLevel;
    }

    public void setCusLevel(Integer cusLevel) {
        this.cusLevel = cusLevel;
    }

    public Integer getCusSatisfacyion() {
        return cusSatisfacyion;
    }

    public void setCusSatisfacyion(Integer cusSatisfacyion) {
        this.cusSatisfacyion = cusSatisfacyion;
    }

    public Integer getCusCredit() {
        return cusCredit;
    }

    public void setCusCredit(Integer cusCredit) {
        this.cusCredit = cusCredit;
    }

    public String getCusAddress() {
        return cusAddress;
    }

    public void setCusAddress(String cusAddress) {
        this.cusAddress = cusAddress;
    }

    public String getCusUrl() {
        return cusUrl;
    }

    public void setCusUrl(String cusUrl) {
        this.cusUrl = cusUrl;
    }

    public String getCusZipcode() {
        return cusZipcode;
    }

    public void setCusZipcode(String cusZipcode) {
        this.cusZipcode = cusZipcode;
    }

    public String getCusPhone() {
        return cusPhone;
    }

    public void setCusPhone(String cusPhone) {
        this.cusPhone = cusPhone;
    }

    public String getCusFox() {
        return cusFox;
    }

    public void setCusFox(String cusFox) {
        this.cusFox = cusFox;
    }

    public Integer getCusStatus() {
        return cusStatus;
    }

    public void setCusStatus(Integer cusStatus) {
        this.cusStatus = cusStatus;
    }

    @Override
    protected Serializable pkVal() {
        return this.cusId;
    }

    @Override
    public String toString() {
        return "Custmer{" +
        "cusId=" + cusId +
        ", cusName=" + cusName +
        ", cusRegion=" + cusRegion +
        ", cusIndusty=" + cusIndusty +
        ", cusLevel=" + cusLevel +
        ", cusSatisfacyion=" + cusSatisfacyion +
        ", cusCredit=" + cusCredit +
        ", cusAddress=" + cusAddress +
        ", cusUrl=" + cusUrl +
        ", cusZipcode=" + cusZipcode +
        ", cusPhone=" + cusPhone +
        ", cusFox=" + cusFox +
        ", cusStatus=" + cusStatus +
        "}";
    }
}
