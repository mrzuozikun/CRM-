package cn.edu.cqrk.controller;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.edu.cqrk.entity.Custmer;
import cn.edu.cqrk.service.ICustmerService;
import cn.edu.cqrk.util.ReportEntity;
import cn.edu.cqrk.util.ReportResult;
import cn.edu.cqrk.util.Result;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author CQRW
 * @since 2020-09-21
 */
@CrossOrigin
@RestController
@RequestMapping("/custmer")
public class CustmerController {
	@Autowired
	private ICustmerService custmerService;
	ReportResult rr = new ReportResult(); 
	
	@RequestMapping("getCustmerCountByLevel")
	public ReportResult getCustmerCountByLevel() {
		List<ReportEntity> list = custmerService.selectCustmerCountByLevel();
		ReportResult rr = new ReportResult(); 
		for(ReportEntity re : list) {
			String levelCn = "";
			switch(re.getItem()) {
				case "1":
					levelCn = "重点客户";
					break;
				case "2":
					levelCn = "普通客户";
					break;
				case "3":
					levelCn = "非优先客户";
					break;
			}
			
			rr.getxAxis().add(levelCn);
			
			rr.getData().add(re.getNum());
		}
		return rr;
	}
	
	

}

